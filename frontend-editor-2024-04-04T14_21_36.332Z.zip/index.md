HTML 

CSS

form fieldset button {
  flex: 1;
  all: unset;
  width: 15%;
  color: rgb(235, 152, 114);
  height: 37px;
  margin-left: 1%;
  margin-right: 1%;
  border-radius: 3px;
  font-size: 80%;
  flex-grow: 1;
}

JS
